/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;
import com.mycompany.guimod1.businesslayer.ConnectionClass;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author danaa
 */
public class SignUp {
    private String name;
    private String phone;
    private String address;
    private String email;
    private String username;
    private String password;
    private String confirmPassword;
    
    public SignUp()
    {

    }
    
    public SignUp(String name, String phone, String address, String email, String username, String password,  String confirmPassword)
    {
         this.name=name;
         this.phone=phone;
         this.address=address;
         this.email=email;
         this.username=username;
         this.password=password;
         this.confirmPassword=confirmPassword;
    }
    public boolean usernameAlreadyTaken(String username)
    {
        try{
            ConnectionClass connection = new ConnectionClass();
            Connection connectionString = connection.getConnectionString();
            
            String sqlQuery = "Select * FROM Users WHERE username = ?";
            try (PreparedStatement preparedStatement = connectionString.prepareStatement(sqlQuery)) {
                // Set the parameter in the query
                preparedStatement.setString(1, username);

                // Execute the query
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    // Check if the result set contains any rows
                    if (resultSet.next()) {
                        System.out.println("Username found in the database.");
                        return true;
                        // You can retrieve other data from the result set if needed
                    } else {
                        System.out.println("Username not found in the database.");
                        return false;
                    }
                }
            }

        } catch(SQLException e)
        {
            e.printStackTrace();
        }
        return true;
    }
    public boolean createAccount() throws ClassNotFoundException
    {
         try {
    
            // Establish a connection to the database
            ConnectionClass connection = new ConnectionClass();
            Connection connectionString=connection.getConnectionString();
            // Define the SQL query for inserting data
            String sqlQuery = "INSERT INTO Clients (name, phone, address, email, username, password) VALUES (?, ?, ?, ?, ?, ?)";
            String sqlQuery2 = "INSERT INTO Users(username, password, type, phone, email) VALUES (?, ?, ?, ?, ?)";
            String type2="client";
            // Create a PreparedStatement
            try (PreparedStatement preparedStatement2 = connectionString.prepareStatement(sqlQuery2)) {
                  // Set the parameters in the query
                preparedStatement2.setString(1, username);
                preparedStatement2.setString(2, password);
                preparedStatement2.setString(3, "client");
                preparedStatement2.setString(4, phone);
                preparedStatement2.setString(5, email);

                // Execute the query
                int rowsAffected2 = preparedStatement2.executeUpdate();
                if (rowsAffected2 > 0) {
                    System.out.println("User Database entry created successfully.");
                } else {
                    System.out.println("Failed to create database entry.");
                }
               
                 try (PreparedStatement preparedStatement = connectionString.prepareStatement(sqlQuery)) {
               // Set the parameters in the query
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, phone);
                preparedStatement.setString(3, address);
                preparedStatement.setString(4, email);
                preparedStatement.setString(5, username);
                preparedStatement.setString(6, password);

                // Execute the query
                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Client Database entry created successfully.");
                } else {
                    System.out.println("Failed to create database entry.");
                }
            }

            // Close the connection
            connectionString.close();
                    return true;
        } 
                                              
            
    } catch(SQLException e){
        e.printStackTrace();
    }
    return false;
}
}
