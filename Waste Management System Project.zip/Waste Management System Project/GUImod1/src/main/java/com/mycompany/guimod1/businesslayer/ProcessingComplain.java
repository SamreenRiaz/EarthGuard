/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author afroz
 */
public class ProcessingComplain {
    public void resolveComplain(int complaintID)
    {
        
    try {
        // Establish database connection
        ConnectionClass conn=new ConnectionClass();
        Connection connection = conn.getConnectionString();
        

        // Prepare the SQL update statement
        String updateSql = "UPDATE Complaints SET status = 'Resolved' WHERE complaintID = ? AND status='Pending'";

        // Create a PreparedStatement to execute the update
        try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
            updateStatement.setInt(1, complaintID);

            // Execute the update
            int rowsUpdated = updateStatement.executeUpdate();

            if (rowsUpdated > 0) {
                // Successfully updated the status
                JOptionPane.showMessageDialog(null, "Complaint Resolved");
            } else {
                // No rows were updated
                JOptionPane.showMessageDialog(null, "Cannot Resolve, Check its not pending.");
            }
        }

        // Close resources
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    }
    
    public void dismissComplain(int complaintID)
    {
        
    try {
        // Establish database connection
        ConnectionClass conn=new ConnectionClass();
        Connection connection = conn.getConnectionString();
        

        // Prepare the SQL update statement
        String updateSql = "UPDATE Complaints SET status = 'Dismissed' WHERE complaintID = ? AND status='Pending'";

        // Create a PreparedStatement to execute the update
        try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
            updateStatement.setInt(1, complaintID);

            // Execute the update
            int rowsUpdated = updateStatement.executeUpdate();

            if (rowsUpdated > 0) {
                // Successfully updated the status
                JOptionPane.showMessageDialog(null, "Complaintt Dismissed");
            } else {
                // No rows were updated
                JOptionPane.showMessageDialog(null, "Cannot Resolve, Check its not pending.");
            }
        }
        

        // Close resources
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    }
    
}
