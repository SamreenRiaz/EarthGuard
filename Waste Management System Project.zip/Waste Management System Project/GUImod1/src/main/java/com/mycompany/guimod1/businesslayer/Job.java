/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import javax.swing.JOptionPane;
import java.sql.*;
//

/**
 *
 * @author afroz
 */
public class Job {
    
//private static final Logger LOGGER = LoggerFactory.getLogger(Job.class);

 public void applicationSubmit(String fullName, String permanentAddress, String phoneNumber, String email, String self) {
    try {
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();

        // Generate a random 3-digit id
        int randomId = new Random().nextInt(900) + 100;

        // Insert data into the Job table using a PreparedStatement
        String jobQuery = "INSERT INTO Job (jobID, fullName, permanentAddress, phoneNumber, email, details) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement jobStatement = connection.prepareStatement(jobQuery)) {
            jobStatement.setInt(1, randomId);
            jobStatement.setString(2, fullName);
            jobStatement.setString(3, permanentAddress);
            jobStatement.setString(4, phoneNumber);
            jobStatement.setString(5, email);
            jobStatement.setString(6, self);

            jobStatement.executeUpdate();
        }

        JOptionPane.showMessageDialog(null, "Applied successfully");

        // Insert data into the Hiring table using a PreparedStatement
        String hiringQuery = "INSERT INTO Hiring (applicantID, applicantName, astatus, details) VALUES (?, ?, 'pending', ?)";
        try (PreparedStatement hiringStatement = connection.prepareStatement(hiringQuery)) {
            hiringStatement.setInt(1, randomId);
            hiringStatement.setString(2, fullName);
            hiringStatement.setString(3, self);

            hiringStatement.executeUpdate();
        }

        // Close the connection
        connection.close();

        System.out.println("Data inserted successfully!");
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

}
