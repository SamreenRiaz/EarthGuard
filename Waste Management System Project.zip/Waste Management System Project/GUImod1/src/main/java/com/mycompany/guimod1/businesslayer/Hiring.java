/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.BorderLayout; // Add this import statement
import java.util.Random;

/**
 *
 * @author afroz
 */
public class Hiring{
    
    public void hiredriver(int applicantID)
    {
        
    try {
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();
        

        // Prepare the SQL update statement
        String updateSql = "UPDATE Hiring SET astatus = 'Accepted' WHERE applicantID = ? AND astatus = 'Pending'";

        // Create a PreparedStatement to execute the update
        try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
            updateStatement.setInt(1, applicantID);

            // Execute the update
            int rowsUpdated = updateStatement.executeUpdate();

            if (rowsUpdated > 0) {
                // Successfully updated the status
                JOptionPane.showMessageDialog(null, "Application Accepted");
                
                String selectJobSql = "SELECT * FROM Job WHERE jobID = ?";

            try (PreparedStatement selectJobStatement = connection.prepareStatement(selectJobSql)) {

                // Set the parameter for the WHERE clause
                selectJobStatement.setInt(1, applicantID);

                // Execute the SELECT query
                ResultSet resultSet = selectJobStatement.executeQuery();

                // Check if there are any results
                if (resultSet.next()) {
                    // Retrieve details from the result set
                    String fullName = resultSet.getString("fullName");
                    String permanentAddress = resultSet.getString("permanentAddress");
                    String phoneNumber = resultSet.getString("phoneNumber");
                    String email = resultSet.getString("email");
                    String details = resultSet.getString("details");
                    
                   // Generate a unique username based on the full name
                        String baseUsername = fullName.replaceAll("\\s+", ""); // Remove spaces
                        String uniqueUsername = generateUniqueUsername(baseUsername); // Call a method to generate a unique username
                        Random random = new Random();
                        int password = 1000 + random.nextInt(9000);
                
// Prepare the INSERT statement for the Users table
                String insertSql = "INSERT INTO Users (id , username, password, type, phone, email) VALUES (?,?, ?, ?, ?, ?)";

                    try (PreparedStatement insertUserStatement = connection.prepareStatement(insertSql)) {
                        // Set values for the INSERT statement
                        insertUserStatement.setInt(1, applicantID);
                        insertUserStatement.setString(2, uniqueUsername);
                        insertUserStatement.setString(3, String.valueOf(password)); //generated above 4 digit random
                        insertUserStatement.setString(4, "driver"); 
                        insertUserStatement.setString(5, phoneNumber);
                        insertUserStatement.setString(6, email);

                        // Execute the INSERT statement
                            int rowsUpdated2 =  insertUserStatement.executeUpdate();

                            if (rowsUpdated2 > 0) {
                                // Successfully updated the status
                                JOptionPane.showMessageDialog(null, "Application Accepted, added as a user");
                            } else {
                                // No rows were updated
                                    JOptionPane.showMessageDialog(null, "Application cannot be Accepted ");
                            }
                        }
                String insertSql2 = "INSERT INTO Driver (driverID ,username, password, address, phoneNumber,ranking  , truckID, email) VALUES (?, ?, ?, ?, ?, ? , ?, ?)";

                    try (PreparedStatement insertUserStatement = connection.prepareStatement(insertSql2)) {
                        // Set values for the INSERT statement
                        insertUserStatement.setInt(1, applicantID);
                        insertUserStatement.setString(2, uniqueUsername);
                        insertUserStatement.setString(3, String.valueOf(password)); //generated above 4 digit random
                        insertUserStatement.setString(4, permanentAddress);
                        insertUserStatement.setString(5, phoneNumber);
                        insertUserStatement.setInt(6, 5);   //initially ranked 5
                        insertUserStatement.setInt(7, 0);   //initially no truck alloted , 0
                        insertUserStatement.setString(8, email);

                        // Execute the INSERT statement
                            int rowsUpdated3 =  insertUserStatement.executeUpdate();

                            if (rowsUpdated3 > 0) {
                                // Successfully updated the status
                                JOptionPane.showMessageDialog(null, "Driver is successfully become a part of Waste management system");
                            } else {
                                // No rows were updated
                                    JOptionPane.showMessageDialog(null, "Cant add driver");
                            }
                        }
                } 
                else {
                    // No results found for the specified job ID
                     JOptionPane.showMessageDialog(null, "Cant find any info");
                }
  
            }
            }
            else 
            {
                // No rows were updated
                    JOptionPane.showMessageDialog(null, "Application is not pending");
            }

        // Close resources
        connection.close();
        }
    } 
        catch (SQLException e) {
        e.printStackTrace();
        }

    }
    
    // Method to generate a unique username
private String generateUniqueUsername(String baseUsername) {
    String username = baseUsername;
    int suffix = 1;
    try{
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();
    try (PreparedStatement checkUsernameStatement = connection.prepareStatement("SELECT * FROM Users WHERE username = ?")) {
        // Check if the generated username already exists
        while (usernameExists(username, checkUsernameStatement)) {
            // If it exists, add a suffix (0-9) to make it unique
            username = baseUsername + suffix;
            suffix++;
        }
    }
    } catch (SQLException e) {
        e.printStackTrace(); // Handle or log the exception as needed
    }

    return username;
}

// Method to check if a username already exists in the Users table
private boolean usernameExists(String username, PreparedStatement checkUsernameStatement) throws SQLException {
    checkUsernameStatement.setString(1, username);
    ResultSet resultSet = checkUsernameStatement.executeQuery();
    return resultSet.next(); // Returns true if username exists, false otherwise
}
    
    
    public void rejectdriver(int applicantID)
    {
    try {
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();
        

        // Prepare the SQL update statement
        String updateSql = "UPDATE Hiring SET astatus = 'Rejected' WHERE applicantID = ? AND astatus = 'Pending'";

        // Create a PreparedStatement to execute the update
        try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
            updateStatement.setInt(1, applicantID);

            // Execute the update
            int rowsUpdated = updateStatement.executeUpdate();

            if (rowsUpdated > 0) {
                // Successfully updated the status
                JOptionPane.showMessageDialog(null, "Application Rejected");
            } else {
                // No rows were updated
            JOptionPane.showMessageDialog(null, "Cannot reject appplication");    
            }
        }
            
        // Close resources
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    }
}
