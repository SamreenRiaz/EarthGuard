/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author DELL
 */
public class complaintfiling {
    public void receiveComplaintData(int clientID, String description, String status) {
        // Process the received data as needed
        System.out.println("Received Complaint Data:");
        System.out.println("Client ID: " + clientID);
        System.out.println("Description: " + description);
        System.out.println("Status: " + status);
        
        // SQL query to insert data into the Complaints table
        String insertQuery = "INSERT INTO Complaints (clientID, description, status) VALUES (?, ?, ?)";

           try {
            // Establish database connection
             ConnectionClass connection = new ConnectionClass();
             Connection connectionString=connection.getConnectionString();
        try (PreparedStatement preparedStatement = connectionString.prepareStatement(insertQuery,PreparedStatement.RETURN_GENERATED_KEYS)) {
            // Set parameter values
            preparedStatement.setInt(1, clientID);
            preparedStatement.setString(2, description);
            preparedStatement.setString(3, status);

            // Execute the query
            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                // Retrieve the auto-generated complaintID (if needed)
                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int complaintID = generatedKeys.getInt(1);
                        System.out.println("Complaint ID: " + complaintID);
                    }
                }

                System.out.println("Complaint data inserted successfully!");
            } else {
                System.out.println("Failed to insert complaint data.");
            }

            // Additional logic if needed
        }
        connectionString.close();
           }catch (SQLException e) {
            e.printStackTrace();  // Handle the exception appropriately
        }
    }
}
    
    

