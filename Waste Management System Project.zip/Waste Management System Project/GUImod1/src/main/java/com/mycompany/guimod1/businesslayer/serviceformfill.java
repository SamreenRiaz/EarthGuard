/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;
import com.mycompany.guimod1.businesslayer.ConnectionClass;
import com.mycompany.guimod1.guiclasses.billform;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author DELL
 */
public class serviceformfill {
    public void receiveDataFromSystemLayer(int id, String name) {
        // Implement your logic to use the received data
        // For example, you can update the UI or perform other operations
        
        System.out.println("Received Data: ID=" + id + ", Name=" + name );
        
        System.out.println("data received");
        // You can add more logic here based on your requirements
    }
    int clientt=0;
      public void searchDatabase(int id, String name) {
        // Implement your logic to search the database based on id and name
        // For example, you can perform a database query

        try {
            // Establish the database connection (replace URL, USER, PASSWORD with your database credentials)
             ConnectionClass connection = new ConnectionClass();
       Connection connectionString=connection.getConnectionString();

            // Prepare the SQL query
            String sql = "SELECT * FROM clients WHERE clientID = ?";
            try (PreparedStatement preparedStatement = connectionString.prepareStatement(sql)) {
                // Set parameters in the prepared statement
                preparedStatement.setInt(1, id);

                // Execute the query
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    // Check if any records were found
                    if (resultSet.next()) {
                        // Record found
                         int clientId = resultSet.getInt("clientID");
                   //     String clientName = resultSet.getString("firstName");
                       

                        System.out.println("Record matched in the database.");
                         billform billform = new billform();
            
            // Pass the clientId or any necessary data to the BillForm
            billform.setClientId(clientId);

            // Make the BillForm visible
            billform.setVisible(true);

                    } else {
                        // No matching record found
                        System.out.println("No matching record found in the database.");
                    }
                }
            }
            
            // Close the database connection
            connectionString.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception according to your requirements
        }

        // You can add more logic here based on your requirements
    }
}
   
