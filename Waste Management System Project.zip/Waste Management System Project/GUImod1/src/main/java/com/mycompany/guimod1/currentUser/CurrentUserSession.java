/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.currentUser;

import com.mycompany.guimod1.businesslayer.User;

/**
 *
 * @author danaa
 */
public class CurrentUserSession {
 
    private static User currentUser;

    private CurrentUserSession() {
        // Private constructor to prevent instantiation
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User user) {
        currentUser = user;
    }

}
