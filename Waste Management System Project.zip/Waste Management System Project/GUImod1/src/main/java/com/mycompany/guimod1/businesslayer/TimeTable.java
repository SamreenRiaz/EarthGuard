/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalTime;

/**
 *
 * @author danaa
 */
public class TimeTable {
    private int pickupID;
    private LocalTime pickuptime;
    private int clientID;
    private String username;
    
    public TimeTable(String username, LocalTime pickuptime)
    {
        this.username=username;
        this.pickuptime=pickuptime;
    }
    
    public int addEntry() {
        
        Client client = new Client(username);
        clientID=client.getIDByUsername(username);
        
        ConnectionClass conn = new ConnectionClass();
        int generatedPickupID = -1; // Initialize to a default value

        try (Connection connection = conn.getConnectionString()) {
            String sql = "INSERT INTO Timetable (pickuptime, clientID) VALUES (?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setTime(1, Time.valueOf(pickuptime));
                preparedStatement.setInt(2, clientID);

                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Entry added to the Timetable table successfully.");

                    // Retrieve the generated key
                    try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            generatedPickupID = generatedKeys.getInt(1);
                        } else {
                            System.out.println("Failed to retrieve the generated pickupID.");
                        }
                    }
                } else {
                    System.out.println("Failed to add entry to the Timetable table.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return generatedPickupID;
    }
}
