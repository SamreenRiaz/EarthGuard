/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.system;

import com.mycompany.guimod1.businesslayer.ApprovingSchedule;
import com.mycompany.guimod1.businesslayer.AvailService;
import com.mycompany.guimod1.businesslayer.ForgotPassword;
import com.mycompany.guimod1.businesslayer.Hiring;
import com.mycompany.guimod1.businesslayer.Job;
import com.mycompany.guimod1.businesslayer.Login;
import com.mycompany.guimod1.businesslayer.ManagingFinances;
import com.mycompany.guimod1.businesslayer.ManagingInventory;
import com.mycompany.guimod1.businesslayer.ProcessingComplain;
import com.mycompany.guimod1.businesslayer.SignUp;
import com.mycompany.guimod1.businesslayer.User;
import com.mycompany.guimod1.businesslayer.complaintfiling;
import com.mycompany.guimod1.businesslayer.paybill;
import com.mycompany.guimod1.businesslayer.performancedriver;
import com.mycompany.guimod1.businesslayer.requestingschedule;
import com.mycompany.guimod1.businesslayer.serviceformfill;
import com.mycompany.guimod1.businesslayer.subscriptionchange;
import com.mycompany.guimod1.currentUser.CurrentUserSession;
import com.mycompany.guimod1.guiclasses.ApplyForJob;
import com.mycompany.guimod1.guiclasses.ApproveSchedule;
import com.mycompany.guimod1.guiclasses.HireDriver;
import com.mycompany.guimod1.guiclasses.LoginGUI;
import com.mycompany.guimod1.guiclasses.ManageFinances;
import com.mycompany.guimod1.guiclasses.ManageInventory;
import com.mycompany.guimod1.guiclasses.ProcessComplains;
import com.mycompany.guimod1.guiclasses.TrackBin;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;
/**
 *
 * @author danaa
 */
public class SystemLayer {
    Job j=new Job();
    Hiring h=new Hiring();
    ProcessingComplain pc=new ProcessingComplain();
    ManagingInventory mi=new ManagingInventory();
    ApprovingSchedule as=new ApprovingSchedule();
    ManagingFinances mf=new ManagingFinances();
    private serviceformfill serviceformfill; // Reference to ServiceFormFill instance
    private performancedriver performancedriver;
    private paybill paybill;
    private complaintfiling complaintfiling;
    private requestingschedule requestingschedule ;
    private subscriptionchange subscriptionchange ;
    public SystemLayer()
    {
        
    }
    public SystemLayer(serviceformfill serviceformfill) {
        this.serviceformfill = serviceformfill;
    }
    
    public SystemLayer(subscriptionchange subscriptionchange) {
        this.subscriptionchange = subscriptionchange;
    }
    public SystemLayer(requestingschedule requestingschedule) {
        this.requestingschedule = requestingschedule;
    }
    public SystemLayer(performancedriver performancedriver ) {
        this.performancedriver = performancedriver;
    }
     
    public SystemLayer(paybill paybill ) {
        this.paybill= paybill;
    }
    public SystemLayer(complaintfiling complaintfiling){  
      
        this.complaintfiling = complaintfiling;
   }
         
    public boolean getLoginDetails(String username, String password)
    {
        Login login = new Login();
        if(login.getLoginDetails(username,password)==true)
            return true;
        else return false;
    }
    public void redirectToClientHome()
    {
        LoginGUI loginGUI = new LoginGUI();
        loginGUI.redirectToClientHome();   
    }
    public void redirectToDriverHome()
    {
        LoginGUI loginGUI = new LoginGUI();
        loginGUI.redirectToDriverHome();   
    }
    public void redirectToAdminHome()
    {
        LoginGUI loginGUI = new LoginGUI();
        loginGUI.redirectToAdminHome();   
    }
    public boolean usernameAlreadyTaken(String username)
    {
        SignUp signup = new SignUp();
        if(signup.usernameAlreadyTaken(username)==true)
            return true;
        return false;
    }
    public boolean checkPassword(String username,String password)
    {
        User user = new User(username,"","",password,"");
        if(user.checkPassword(username,password))
            return true;
        return false;
    }
    public boolean createAccount(String name, String phone, String address, String email, String username, String password,  String confirmPassword)
    {
        SignUp signup = new SignUp(name,phone,address,email,username,password,confirmPassword);
        try {
        if (signup.createAccount()) {
            return true;
        } else {
            return false;
        }
        }  catch (ClassNotFoundException e) {
            e.printStackTrace(); // or log the exception using a logging framework
            // Handle the ClassNotFoundException as needed
            return false; // or throw a different exception, log, etc.
        }
    }
    public boolean verifyPhone(String phone)
    {
        ForgotPassword forgotPass = new ForgotPassword("",phone);
        if(forgotPass.verifyPhone())
            return true;
        return false;
    }
    public boolean verifyEmail(String email)
    {
        ForgotPassword forgotPass = new ForgotPassword(email,"");
        if(forgotPass.verifyEmail())
            return true;
        return false;
    }
    public boolean changePassword(String email, String phone, String password)
    {
        ForgotPassword forgotPass = new ForgotPassword(email,phone,password);
        if(forgotPass.changePassword())
            return true;
        return false;
    }
    User currentUser = CurrentUserSession.getCurrentUser();
    public String getUsername()
    {
        return currentUser.getUsername();
    }
    public String getEmail()
    {
        return currentUser.getEmail();
    }
    public String getPhone()
    {
        return currentUser.getPhone();
    }
    public boolean availService(int serviceId, double price, String username, String billAdd, LocalTime time, LocalDate date,String permAdd,String phone, int subscriptionId, String email)
    {
        AvailService availService = new AvailService(serviceId,price,username,time,date,subscriptionId,email,phone,billAdd,permAdd);
        if(availService.availService())
            return true;
        return false;
    }
    public void applyforajob() {
        ApplyForJob applyForJob=new ApplyForJob();
                  applyForJob.setVisible(true);
    }
   public void submitapplication(String name,String address, String phonenumber, String email, String self)
   {
       j.applicationSubmit(name, address, phonenumber, email, self);
   }
    public void performHireDriver() {
        HireDriver hireDriver = new HireDriver();
        hireDriver.setVisible(true);
        // Close the previous frame
    }
    public void applicationapproval(int applicationid)
    {
        h.hiredriver(applicationid);
    }
    public void applicationrejection(int applicationid)
    {
        h.rejectdriver(applicationid);
    }
    public void resolveComplain(int complainid)
    {
        pc.resolveComplain(complainid);
    }
    public void dismissComplain(int complainid)
    {
        pc.dismissComplain(complainid);
    }
    public void addingbins(String selectedValue)
    {
        if(selectedValue=="Bin")
        {
            mi.addbin();
        }
        else if(selectedValue=="RecyclingBin")
        {
            mi.addrecyclingbin();
        }
        else if(selectedValue=="Dumpster")
        {
            mi.adddumpster();
        }
    }
    public void removingbins(String selectedValue, int id)
    {
        if(selectedValue=="Bin")
        {
            mi.removebin(id);
        }
        else if(selectedValue=="RecyclingBin")
        {
            mi.removerecyclingbin(id);
        }
        else if(selectedValue=="Dumpster")
        {
            mi.removedumpster(id);
        }
    }
    public void approveschedulechange(String requestedtime, int requestId, int clientrequested)
    {
        as.approveschedule(requestedtime, requestId, clientrequested);
    }
    public void rejectchedulechange(int requestid)
    {
        as.rejectschedule(requestid);
    }
    public void updateplan(float charges, String plantype)
    {
        mf.update(charges, plantype);
    }
    public void performTrackBin() {
        TrackBin trackBin = new TrackBin();
        trackBin.setVisible(true);
        // Close the previous frame
    }

    public void performProcessComplaints() {
        ProcessComplains processComplaints = new ProcessComplains();
        processComplaints.setVisible(true);
        // Close the previous frame
    }

    public void performManageInventory() {
        ManageInventory manageInv = new ManageInventory();
        manageInv.setVisible(true);
        // Close the previous frame
    }

    public void performManageFinances() {
        ManageFinances manageFin = new ManageFinances();
        manageFin.setVisible(true);
    }

   public void performApproveSchedule() {
        ApproveSchedule approveSch = new ApproveSchedule();
        approveSch.setVisible(true);
    }
          public void processClientData(int id, String name) {
     
        System.out.println("Processing Client Data - ID: " + id + ", Name: " + name);
         serviceformfill.receiveDataFromSystemLayer(id, name);
         serviceformfill.searchDatabase(id, name);
  
    }
       
      public void appreciateDriver(int clientId, int driversId, int rank) {
    

        // Print a message for demonstration purposes
        System.out.println("Appreciating Driver:");
        System.out.println("ClientID: " + clientId);
        System.out.println("DriverID: " + driversId);
        System.out.println("Rank: " + rank);  
        
         performancedriver.receiveDataFromSystemLayer(clientId, driversId, rank);
          performancedriver.insertDataIntoDatabase(clientId, driversId, rank);
}
      public void payingbill(int billID)
      {
           System.out.println("Bill ID received is ");
        System.out.println("billID " + billID);
          paybill.updateBillAmountToZero( billID);
      }
      
      public void handleComplaint(int clientID, String description, String status) {
        // Process the complaint data as needed
        //System.out.println("Client ID: " + clientID);
        //System.out.println("Description: " + description);
        //System.out.println("Status: " + status);
       complaintfiling.receiveComplaintData(clientID, description, status);
    }
      
    public void requestschedule(int clientID, String scheduletime, String status) {
        // Process the complaint data as needed
        //System.out.println("Client ID: " + clientID);
        //System.out.println("Description: " + description);
        //System.out.println("Status: " + status);
        requestingschedule.receivescheduleData(clientID, scheduletime, status);
    }
    
       public void requestsubscriptionpackage(String username, int subscriptionid,int serviceid) {
        // Process the complaint data as needed
        //System.out.println("Client ID: " + clientID);
        //System.out.println("Description: " + description);
        //System.out.println("Status: " + status);
        subscriptionchange.resubscriptioneData(username,subscriptionid,serviceid);
    }
   
}
