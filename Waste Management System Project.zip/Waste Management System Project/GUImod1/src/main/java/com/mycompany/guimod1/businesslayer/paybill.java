/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import com.mycompany.guimod1.guiclasses.billpayed;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author DELL
 */
public class paybill {
    
     public void updateBillAmountToZero(int billID)
     {
        String updateQuery = "UPDATE Bill SET amountDue = 0 WHERE billID = ?";

        try{
          ConnectionClass connection = new ConnectionClass();
          Connection connectionString=connection.getConnectionString(); 
            try (PreparedStatement preparedStatement = connectionString.prepareStatement(updateQuery)) {
                preparedStatement.setInt(1, billID);
                preparedStatement.executeUpdate();
                System.out.println("Bill amount updated to 0 successfully!");
            }
        connectionString.close();
        }
        catch(SQLException e) {
            e.printStackTrace();
        }
          billpayed billpayed = new billpayed();
          billpayed.setVisible(true);
     
    
}
}
