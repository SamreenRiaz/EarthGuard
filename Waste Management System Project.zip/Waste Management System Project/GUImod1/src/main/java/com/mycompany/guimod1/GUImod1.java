/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.guimod1;

import com.mycompany.guimod1.businesslayer.ConnectionClass;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author danaa
 */
public class GUImod1 {
    
   public static void main(String args[])
   {
       
   }
   private static void viewData() throws SQLException {
       
   }
    
} // class ends
