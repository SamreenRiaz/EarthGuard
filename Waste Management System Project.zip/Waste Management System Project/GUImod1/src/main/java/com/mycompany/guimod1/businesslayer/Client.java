/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author danaa
 */
public class Client {
    private String username;
    
    public Client(String username)
    {
        this.username=username;
    }
    public int getIDByUsername(String username)
    {
        int id=0;
        this.username=username;
        ConnectionClass connClass= new ConnectionClass();
        try (Connection connection = connClass.getConnectionString()) {
            String sql = "SELECT id FROM Clients WHERE username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, username);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // Retrieve the client ID from the result set
                        int clientId = resultSet.getInt("id");
                    System.out.println("Client ID for username '" + username + "': " + clientId);
                        return clientId;
                    } else {
                        System.out.println("No client found with the username: " + username);
                        return 0;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }

    }
}
