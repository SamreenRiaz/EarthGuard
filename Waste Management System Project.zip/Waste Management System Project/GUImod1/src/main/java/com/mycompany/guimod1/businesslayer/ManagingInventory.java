/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author afroz
 */
public class ManagingInventory {
  
    public void addbin()
    {
 
        try{
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();
        String sql = "INSERT INTO Bin (binID, status, capacity, location, binType) VALUES (?, 0, 40, NULL, 'non recycling bin')";
            try(PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            // Generate a unique identifier for id
            int randomId = new Random().nextInt(900) + 100;
            

            // Set values for parameters
            preparedStatement.setInt(1, randomId);

            // Execute the query
            preparedStatement.executeUpdate();
                }
            JOptionPane.showMessageDialog(null, "Bin added successfully");
            
        }
        catch (SQLException e) {
        e.printStackTrace();
    }
    }   
    public void addrecyclingbin()
    {
 
        try{
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();
        String sql = "INSERT INTO RecyclingBin (recyclingBinId, status) VALUES (?, 0)";
            try(PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            // Generate a unique identifier for id
            int randomId = new Random().nextInt(900) + 100;
            

            // Set values for parameters
            preparedStatement.setInt(1, randomId);

            // Execute the query
            preparedStatement.executeUpdate();
                }
            JOptionPane.showMessageDialog(null, "Recycling Bin added successfully");
            
        }
        catch (SQLException e) {
        e.printStackTrace();
    }
    }
    public void adddumpster()
    {
        try{
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();
        String sql = "INSERT INTO Dumpster (dumpsterId, status) VALUES (?, 0)";
            try(PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            // Generate a unique identifier for id
            int randomId = new Random().nextInt(900) + 100;
            

            // Set values for parameters
            preparedStatement.setInt(1, randomId);

            // Execute the query
            preparedStatement.executeUpdate();
                }
            JOptionPane.showMessageDialog(null, "Dumpster added successfully");
            
        }
        catch (SQLException e) {
        e.printStackTrace();
    }
    }
    ///////////////////////REMOVING//////////////////////////////////////////
    public void removebin(int removeid)
    {
 
        try{
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();
        String sql = "DELETE FROM Bin WHERE Binid = ? AND status = 0";
            try(PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            
            preparedStatement.setInt(1, removeid);
            // Execute the query
            int rowsAffected=preparedStatement.executeUpdate();
            if(rowsAffected>0)
            {
                JOptionPane.showMessageDialog(null, "Bin Removed successfully");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Cannot remove bin, its in use");
            }
          }
            
        }
        catch (SQLException e) {
        e.printStackTrace();
    }
    }
    public void removerecyclingbin(int removeid)
    {
 
        try{
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();
        String sql = "DELETE FROM RecyclingBin WHERE recyclingBinId = ? AND status = 0";
            try(PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            
            preparedStatement.setInt(1, removeid);
            // Execute the query
            int rowsAffected=preparedStatement.executeUpdate();
                
            if(rowsAffected>0)
            {
            JOptionPane.showMessageDialog(null, "Recycling Bin Removed successfully");    
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Cannot remove Recycling bin, its in use");     
            }
            }
        }
        catch (SQLException e) {
        e.printStackTrace();
    }
    }
    public void removedumpster(int removeId) {
    boolean success = false;
    ConnectionClass conn = new ConnectionClass();
        
    try (Connection connection = conn.getConnectionString()) {
        String sql = "DELETE FROM Dumpster WHERE dumpsterId = ? AND status = 0";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, removeId);

            // Execute the query
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Dumpster removed successfully");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Cannot remove dumpster, it's already in use");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

}