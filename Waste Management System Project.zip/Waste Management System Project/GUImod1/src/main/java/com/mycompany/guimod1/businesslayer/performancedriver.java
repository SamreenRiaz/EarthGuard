/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;




import com.mycompany.guimod1.businesslayer.ConnectionClass;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author DELL
 */
public class performancedriver {
         public void receiveDataFromSystemLayer(int clientId, int driversId, int rank) {
      
        System.out.println("Received Data in PerformanceDriver:");
        System.out.println("ClientID: " + clientId);
        System.out.println("DriverID: " + driversId);
        System.out.println("Rank: " + rank);

     
    }
           // Method to insert data into the database
    public void insertDataIntoDatabase(int clientId, int driverId, int rank) {
       
        String insertQuery = "INSERT INTO Driver ( driverID, ranking) VALUES (?, ?)";
        
        String updateQuery = "UPDATE Driver SET ranking = ? WHERE driverID = ?";

        try {
            // Establish the database connection
          ConnectionClass connection = new ConnectionClass();
       Connection connectionString=connection.getConnectionString();

            PreparedStatement preparedStatement = connectionString.prepareStatement(updateQuery);
         {
            // Set values for parameters in the prepared statement
            preparedStatement.setInt(1, rank);
            preparedStatement.setInt(2, driverId);

            // Execute the query to update data
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Driver's rank updated successfully!");
            } else {
                System.out.println("Driver with ID " + driverId + " not found.");
            }

        }
         connectionString.close();
        }
         catch (SQLException e) {
            e.printStackTrace();
           
    }
}
    }
