/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author danaa
 */
public class User {
    private String username;
    private String phone;
    private String email;
    private String password;
    private String type;
    public User()
    {
        
    }
    public User(String username, String phone, String email, String password, String type)
    {
        this.username=username;
        this.phone=phone;
        this.email=email;
        this.password=password;
        this.type=type;
    }
    public String getUsername(){
        return username;
    }
    public String getEmail(){
        return email;
    }
    public String getPassword(){
        return password;
    }
    public String getType(){
        return type;
    }
     public String getPhone(){
        return phone;
    }
    public boolean checkPassword(String username, String password)
    {
        ConnectionClass conn = new ConnectionClass();
        try (Connection connection = conn.getConnectionString()) {
            // Check if the username exists in the database
            String query = "SELECT * FROM Users WHERE username = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // User found, compare passwords
                        String storedPassword = resultSet.getString("password");
                        if(storedPassword.equals(password))
                            return true;
                        return false;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately in a real-world scenario
            return false;
        }
        return false;
    }
}

