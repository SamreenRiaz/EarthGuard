/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author danaa
 */
public class ForgotPassword {
    String email;
    String password;
    String phone;
    
    public ForgotPassword(String email, String phone)
    {
        this.email=email;
        this.phone=phone;
    }
     public ForgotPassword(String email, String phone, String password)
    {
        this.email=email;
        this.phone=phone;
        this.password=password;
    }
    public boolean verifyEmail()
    {
        boolean emailExists = false;
        ConnectionClass connClass = new ConnectionClass();
        
        // JDBC variables for opening, closing, and managing the connection
        try (Connection connection = connClass.getConnectionString()) {
            // SQL query to check if the email exists
            String sql = "SELECT COUNT(*) FROM Users WHERE email = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, email);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt(1);
                        emailExists = count > 0;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return emailExists;
    }
    public boolean verifyPhone()
    {
        boolean phoneExists = false;
        ConnectionClass connClass = new ConnectionClass();
        
        // JDBC variables for opening, closing, and managing the connection
        try (Connection connection = connClass.getConnectionString()) {
            // SQL query to check if the email exists
            String sql = "SELECT COUNT(*) FROM Users WHERE phone = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, phone);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt(1);
                        phoneExists = count > 0;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return phoneExists;
    }
    public boolean changePassword()
    {
         try {
        String emailOrPhone = (email.equals("")) ? phone : email;

        // Establish a connection to the database
        ConnectionClass connection = new ConnectionClass();
        Connection conn = connection.getConnectionString();

        // Retrieve type from Users table
        String getUserTypeQuery = "SELECT type FROM Users WHERE phone = ? OR email = ?";
        String type = "";

        try (PreparedStatement userTypeStmt = conn.prepareStatement(getUserTypeQuery)) {
            userTypeStmt.setString(1, emailOrPhone);
            userTypeStmt.setString(2, emailOrPhone);

            try (ResultSet resultSet = userTypeStmt.executeQuery()) {
                if (resultSet.next()) {
                    type = resultSet.getString("type");
                }
            }
        }

        // Define the SQL query for updating the password in Users table
        String updateUsersQuery = "UPDATE Users SET password = ? WHERE phone = ? OR email = ?";

        // Use try-with-resources to automatically close resources
        try (PreparedStatement updateUsersStmt = conn.prepareStatement(updateUsersQuery)) {
            // Set parameters for updating Users table
            updateUsersStmt.setString(1, password);
            updateUsersStmt.setString(2, emailOrPhone);
            updateUsersStmt.setString(3, emailOrPhone);

            // Execute the update
            int usersRowsAffected = updateUsersStmt.executeUpdate();

            // Check if any rows were affected
            if (usersRowsAffected > 0) {
                System.out.println("Password updated successfully in Users table.");

                // Define the SQL query for updating the password in the related table based on type
                String updateRelatedTableQuery = "UPDATE " +
                        ((type.equals("client")) ? "Clients" :
                                (type.equals("driver") ? "Driver" :
                                        (type.equals("admin") ? "Admin" : ""))) +
                        " SET password = ? WHERE phone = ? OR email = ?";

                // Use try-with-resources to automatically close resources
                try (PreparedStatement updateRelatedTableStmt = conn.prepareStatement(updateRelatedTableQuery)) {
                    // Set parameters for updating related table based on type
                    updateRelatedTableStmt.setString(1, password);
                    updateRelatedTableStmt.setString(2, emailOrPhone);
                    updateRelatedTableStmt.setString(3, emailOrPhone);

                    // Execute the update
                    int relatedTableRowsAffected = updateRelatedTableStmt.executeUpdate();

                    // Check if any rows were affected
                    if (relatedTableRowsAffected > 0) {
                        System.out.println("Password updated successfully in " + type + " table.");
                        return true;
                    } else {
                        System.out.println("Failed to update password in " + type + " table.");
                    }
                }
            } else {
                System.out.println("Failed to update password in Users table.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the connection
            if (conn != null) {
                conn.close();
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
     }
        return false;
     }
}
