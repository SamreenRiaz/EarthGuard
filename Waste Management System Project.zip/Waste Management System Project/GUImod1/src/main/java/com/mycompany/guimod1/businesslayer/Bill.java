/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

/**
 *
 * @author danaa
 */
public class Bill {
    //int billID;
    int clientID;
    int pickupID;
    String username;
    double amountDue;
    LocalDate date;
//    FOREIGN KEY (clientID) REFERENCES Clients(id)
    public Bill(String username,double amountDue, LocalDate date,int pickupID) {
        this.username=username;
        this.amountDue = amountDue;
        this.date = date;
        this.pickupID=pickupID;
    }
    // Getter and setter for billID
//    public int getBillID() {
//        return billID;
//    }
//
//    public void setBillID(int billID) {
//        this.billID = billID;
//    }

    // Getter and setter for clientID
    public int getClientID() {
        return clientID;
    }

    public void setClientID(int clientID) {
        this.clientID = clientID;
    }

    // Getter and setter for pickupID
    public int getPickupID() {
        return pickupID;
    }

    public void setPickupID(int pickupID) {
        this.pickupID = pickupID;
    }

    // Getter and setter for amountDue
    public double getAmountDue() {
        return amountDue;
    }

    public void setAmountDue(double amountDue) {
        this.amountDue = amountDue;
    }

    // Getter and setter for date
    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
    public int addEntry() {
        Client client = new Client(username);
        clientID = client.getIDByUsername(username);

        int generatedBillID = -1; // Initialize to a default value
        ConnectionClass connClass = new ConnectionClass();
        try (Connection connection = connClass.getConnectionString()) {
            String sql = "INSERT INTO Bill (clientID, pickupID, amountDue, dueDate) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setInt(1, clientID);
                preparedStatement.setInt(2, pickupID);
                preparedStatement.setDouble(3, amountDue);
                preparedStatement.setObject(4, date);

                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Entry added to the Bill table successfully.");

                    // Retrieve the generated key
                    try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            generatedBillID = generatedKeys.getInt(1);
                        } else {
                            System.out.println("Failed to retrieve the generated billID.");
                        }
                    }
                } else {
                    System.out.println("Failed to add entry to the Bill table.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return generatedBillID;
    }
}
