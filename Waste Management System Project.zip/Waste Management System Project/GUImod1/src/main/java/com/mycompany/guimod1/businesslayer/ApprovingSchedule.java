/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author afroz
 */
public class ApprovingSchedule {
    
    public void approveschedule(String requestedtime, int requestId, int clientrequested) {
    try {
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();

        // Update status in ScheduleChangeRequest
        String updateStatusSql = "UPDATE ScheduleChangeRequest SET status = '1' WHERE requestID = ?";
        try (PreparedStatement updateStatusStatement = connection.prepareStatement(updateStatusSql)) {
            updateStatusStatement.setInt(1, requestId);

            // Execute the update
            int rowsUpdated = updateStatusStatement.executeUpdate();

            if (rowsUpdated > 0) {
                // Successfully updated the status
                JOptionPane.showMessageDialog(null, "Schedule Request Accepted");

                // Update pickuptime in Timetable
                String updatePickupTimeSql = "UPDATE Timetable SET pickuptime = ? WHERE clientID = ?";
                try (PreparedStatement updatePickupTimeStatement = connection.prepareStatement(updatePickupTimeSql)) {
                    // Set the new pickuptime and pickupID for the update
                    updatePickupTimeStatement.setTime(1, java.sql.Time.valueOf(requestedtime));
                    updatePickupTimeStatement.setInt(2, clientrequested);

                    // Execute the update
                    updatePickupTimeStatement.executeUpdate();
                }

                JOptionPane.showMessageDialog(null, "Pickup Time Updated in Timetable");
            } else {
                // No rows were updated in ScheduleChangeRequest
                JOptionPane.showMessageDialog(null, "Schedule Request can't be Accepted, Try Again");
            }
        }

        // Close resources
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    
    public void rejectschedule(int requestId)
    {
        try {
        // Establish database connection
          ConnectionClass conn = new ConnectionClass();
          Connection connection = conn.getConnectionString();
        

        // Prepare the SQL update statement
        String updateSql = "UPDATE ScheduleChangeRequest SET status = '-1' WHERE requestID = ?";

        // Create a PreparedStatement to execute the update
        try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
            updateStatement.setInt(1, requestId);

            // Execute the update
            int rowsUpdated = updateStatement.executeUpdate();

            if (rowsUpdated > 0) {
                // Successfully updated the status
                    JOptionPane.showMessageDialog(null, "Schedule Request Rejected");        
            } else {
                // No rows were updated
                JOptionPane.showMessageDialog(null, "Schedule Request cant be rejected, Try Again");        
            }
        }
        

        // Close resources
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
    
    
}
