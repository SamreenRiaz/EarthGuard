/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.math.BigDecimal;
/**
 *
 * @author afroz
 */
public class ManagingFinances {
    public void update(float charges , String plantype)
    {
        try {
        // Establish database connection
        ConnectionClass conn = new ConnectionClass();
        Connection connection = conn.getConnectionString();
        

        // Prepare the SQL update statement
        String updateSql = "UPDATE Subscription SET charges = ? WHERE planType = ?";

        // Create a PreparedStatement to execute the update
        try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
            BigDecimal chargesBigDecimal = BigDecimal.valueOf(charges);
            updateStatement.setBigDecimal(1, chargesBigDecimal);
            updateStatement.setString(2, plantype);

            // Execute the update
            int rowsUpdated = updateStatement.executeUpdate();

            if (rowsUpdated > 0) {
                // Successfully updated the status
                JOptionPane.showMessageDialog(null, "Charges are updated");
            } else {
                // No rows were updated
            JOptionPane.showMessageDialog(null, "Cannot update charges " + plantype + " . Current charges: " + charges);    
            }
        }
            
        // Close resources
        connection.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
}
