/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;
import com.mycompany.guimod1.currentUser.CurrentUserSession;
import com.mycompany.guimod1.system.SystemLayer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author danaa
 */
public class Login {
    private String username;
    private String password;
    
    public boolean getLoginDetails(String username, String password)
    {
        this.username=username;
        this.password=password;
        //display username and password to check
        //System.out.println("username received in login class: "+ username + " password: " + password);
        try{
            if(checkLoginDetails()==true)
                return true;
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean checkLoginDetails() throws SQLException
    {
        if(username.length()<20 && password.length()<15)
        {
            try {
                ConnectionClass connection = new ConnectionClass();
                Connection connectionString=connection.getConnectionString();
                
                String sql = "SELECT * FROM Users";
                try (PreparedStatement preparedStatement = connectionString.prepareStatement(sql);
                     ResultSet resultSet = preparedStatement.executeQuery()) {
                       while (resultSet.next()) {
                           String user = resultSet.getString("username");
                           String pass= resultSet.getString("password");
                           String userType = resultSet.getString("type");
                           String email = resultSet.getString("email");
                           String phone = resultSet.getString("phone");
                           
                           System.out.println("username: " + user +
                                   ", password: " + pass + ", type: " + userType);
                           if(username.equals(user) && password.equals(pass) && userType.equals("client"))
                           {
                               User loggedInUser = new User(username, phone, email, password, "client");
                               CurrentUserSession.setCurrentUser(loggedInUser);
                               connectionString.close();
                               redirectToClientHome();
                               return true;
                           }
//                           else if(username.equals(user) && password.equals(pass) && userType.equals("driver"))
//                           {
//                               connectionString.close();
//                               redirectToDriverHome();
//                               return true;
//                           }
                           else if(username.equals(user) && password.equals(pass) && userType.equals("admin"))
                           {
                               User loggedInUser = new User(username, phone, email, password, "admin");
                               CurrentUserSession.setCurrentUser(loggedInUser);
                               connectionString.close();
                               redirectToAdminHome();
                               return true;
                           }
                       }
                       connectionString.close();
                       return false;
                }

             } catch (SQLException e) {
                 e.printStackTrace();
                 return false;
             }
        }
        return false;
    }
    public void redirectToClientHome()
    {
        System.out.println("redirecting to clients' homepage...");
        SystemLayer system = new SystemLayer();
        system.redirectToClientHome();
    }
    public void redirectToAdminHome()
    {
        System.out.println("redirecting to admins' homepage...");
        SystemLayer system = new SystemLayer();
        system.redirectToAdminHome();
    }
    public void redirectToDriverHome()
    {
        System.out.println("redirecting to drivers' homepage...");
        SystemLayer system = new SystemLayer();
        system.redirectToDriverHome();
    }
}
