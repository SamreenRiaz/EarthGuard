/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author DELL
 */
public class subscriptionchange {
    
         public void resubscriptioneData(String username, int subscriptionid,int serviceid) {
         // Process the received data as needed
                String sql = "UPDATE AvailService SET subscriptionId = ? WHERE username = ? AND serviceId = ?";
                ConnectionClass conn = new ConnectionClass();
                try (Connection connection = conn.getConnectionString();
                     PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

                    preparedStatement.setInt(1, subscriptionid);
                    preparedStatement.setString(2, username);
                    preparedStatement.setInt(3, serviceid);
                    
                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        System.out.println("Subscription ID updated successfully.");
                    } else {
                        System.out.println("No records found for the given client username.");
                    }

                } catch (SQLException e) {
                    e.printStackTrace(); // Handle the exception based on your application's needs
                }
        }
}
