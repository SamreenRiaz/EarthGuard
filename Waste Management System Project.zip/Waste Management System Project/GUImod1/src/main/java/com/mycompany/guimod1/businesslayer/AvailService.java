/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.guimod1.businesslayer;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author danaa
 */
public class AvailService {
    int serviceId;
    String username;
    double price;
    int billId;
    int pickupId;
    int subscriptionId;
    LocalTime time; //for TimeTable
    LocalDate date; //for Bill
    String email;
    String phone;
    String billAddress;
    String permAddress;
    
    public AvailService(int serviceId, double price, String username, LocalTime time, LocalDate date,int subscriptionId, String email, String phone, String billAddress, String permAddress)
    {
        this.serviceId=serviceId;
        this.username=username;
        this.billAddress=billAddress;
        this.phone=phone;
        this.time=time;
        this.date=date;
        this.price=price;
        this.subscriptionId=subscriptionId;
        this.email=email;
        this.permAddress=permAddress;
    }
    
    public boolean availService()
    {
        //first add entry to bill table
      
        
        TimeTable timeTable = new TimeTable(username,time);
        pickupId=timeTable.addEntry();
        Bill bill = new Bill(username,price,date,pickupId);
        billId=bill.addEntry();
        System.out.println("BILL ID: "+billId+" PICKUP ID: "+pickupId);
        boolean flag=false;
        try{
            flag=addEntry();
        }catch(SQLException e){
            e.printStackTrace();
        }
        return flag;
    }
     public boolean addEntry() throws SQLException {
        
        
        ConnectionClass conn = new ConnectionClass();
        int generatedPickupID = -1; // Initialize to a default value

        try (Connection connection = conn.getConnectionString()) {
            String sql = "INSERT INTO AvailService (serviceId, username, billId, pickupId, subscriptionId, email, phone, billingAdd, permAdd) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setInt(1, serviceId);
                preparedStatement.setString(2, username);
                preparedStatement.setInt(3, billId);
                preparedStatement.setInt(4, pickupId);
                preparedStatement.setInt(5, subscriptionId);
                preparedStatement.setString(6, email);
                preparedStatement.setString(7, phone);
                preparedStatement.setString(8, billAddress);
                preparedStatement.setString(9, permAddress);
                
                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Entry added to the Timetable table successfully.");
                    return true;
                } else {
                    System.out.println("Failed to add entry to the Timetable table.");
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
